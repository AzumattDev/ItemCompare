| `Version` | `Update Notes`                                                                                                 |
|-----------|----------------------------------------------------------------------------------------------------------------|
| 1.0.3     | - Recompile for Ashlands. Remove stamina comparison for now until I get around to displaying all the new ones. |
| 1.0.2     | - Some fixes for those that use gamepad for a PC game.                                                         |
| 1.0.1     | - Fix for JC API, my fault.                                                                                    |
| 1.0.0     | - Initial Release                                                                                              |